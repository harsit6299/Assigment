import pandas as pd
import numpy as np

def parse_dates_safe(df, cols):
    for c in cols:
        if c in df.columns:
            df[c] = pd.to_datetime(df[c], errors='coerce', utc=True)
    return df

def standardize_cols(df):
    df.columns = [c.strip().lower().replace(' ', '_') for c in df.columns]
    return df

def label_direction(row):
    try:
        if 'side' in row and 'size' in row:
            s = str(row['side']).lower()
            return 1 if s in ('buy','long') else -1 if s in ('sell','short') else 0
    except Exception:
        pass
    return 0

def safe_num(x):
    try:
        return float(x)
    except Exception:
        return np.nan
