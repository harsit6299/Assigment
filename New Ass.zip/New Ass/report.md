# Findings (Auto-Draft with Explicit Mapping)

## Overall by Sentiment
| classification   |   trades |   win_rate |   avg_pnl |   p95_loss |   p95_gain |   avg_size |
|:-----------------|---------:|-----------:|----------:|-----------:|-----------:|-----------:|
| unknown          |   211224 |   0.411265 |    48.749 |   -5.32101 |    165.789 |    4623.36 |

## Welch t-test
Not enough data for t-test.

## Model summary
Logit ROC-AUC=0.500
              precision    recall  f1-score   support

           0      0.589     1.000     0.741     31089
           1      0.000     0.000     0.000     21717

    accuracy                          0.589     52806
   macro avg      0.294     0.500     0.371     52806
weighted avg      0.347     0.589     0.436     52806
